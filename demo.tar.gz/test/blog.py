#-*- coding : utf-8-*-
import sqlite3
from flask import Flask, render_template, request, url_for, flash, redirect, app, send_file, get_flashed_messages
import requests
import rpy2.robjects as ro
from io import BytesIO
from io import StringIO
from PIL import Image
import base64
from rpy2.robjects import globalenv
from rpy2 import robjects
r = robjects.r
import os
import pandas as pd
import time
from plotnine import *
from rpy2.robjects.packages import importr
import rpy2.robjects as ro



from rpy2.robjects import pandas2ri
pandas2ri.activate()





app = Flask(__name__)
app.config['SECRET_KEY'] = 'matrekaap is a handsome and simple guy'
app.secret_key = 'asdfasdf'

# 创建一个函数用来获取数据库链接
def get_db_connection():
    # 创建数据库链接到database.db文件
    conn = sqlite3.connect('database.db')
    # 设置数据的解析方法，有了这个设置，就可以像字典一样访问每一列数据
    conn.row_factory = sqlite3.Row
    return conn

# 根据post_id从数据库中获取post
def get_post(post_id):
    conn = get_db_connection()
    post = conn.execute('SELECT * FROM posts WHERE id = ?',
                        (post_id,)).fetchone()
    conn.close()
    return post


@app.route('/') 
def index():
    # 调用上面的函数，获取链接
    conn = get_db_connection()
    # 查询所有数据，放到变量posts中
    posts = conn.execute('SELECT * FROM posts').fetchall()
    conn.close()
    #把查询出来的posts传给网页
    return render_template('index.html', posts=posts)  


@app.route('/posts/<int:post_id>')
def post(post_id):
    post = get_post(post_id)
    return render_template('post.html', post=post)


@app.route('/posts/new', methods=('GET', 'POST'))
def new():
    if request.method == 'POST':
        title = request.form['title']
        content = request.form['content']


        if not title:
            flash('标题不能为空!')
        elif not content:
            flash('内容不能为空')
        else:
            conn = get_db_connection()
            conn.execute('INSERT INTO posts (title, content) VALUES (?, ?)',
                         (title, content))
            conn.commit()
            conn.close()
            return redirect(url_for('index'))

    return render_template('new.html')


@app.route('/posts/<int:id>/edit', methods=('GET', 'POST'))
def edit(id):
    post = get_post(id)

    if request.method == 'POST':
        title = request.form['title']
        content = request.form['content']

        if not title:
            flash('Title is required!')
        else:
            conn = get_db_connection()
            conn.execute('UPDATE posts SET title = ?, content = ?'
                         ' WHERE id = ?',
                         (title, content, id))
            conn.commit()
            conn.close()
            return redirect(url_for('index'))

    return render_template('edit.html', post=post)


@app.route('/posts/<int:id>/delete', methods=('POST',))
def delete(id):
    post = get_post(id)
    conn = get_db_connection()
    conn.execute('DELETE FROM posts WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    flash('"{}" 删除成功!'.format(post['title']))
    return redirect(url_for('index'))
@app.route('/about')
def about():
    return render_template('about.html')


@app.route('/plot', methods=('GET', 'POST'))
def plot():
    #flash('flash test')
    if request.method == 'POST':
        """
        print(type(request.form['X-axis variable']))
        if len(request.form['X-axis variable']) ==0:
            print("test")
            flash('X-axis variable is required!please choose one!')
            print("test2")
            return render_template('plot.html', img=url_for('static', filename='img/white.png'))
            print("test3")
        else:
            print("pass")
        print(request.form['X-axis variable order'])
        """
        start_time = time.time()
        global title, content, X_axis_variable, X_axis_variable_order, Y_axis_variable, Color_variable, Colors_vector ,X_axis_variable_font_size, Y_axis_variable_font_size, Legend_font_size
        title = request.form['title']
        content = request.form['content']
        X_axis_variable = request.form['X-axis variable']
        X_axis_variable_order= request.form['X-axis variable order']
        Y_axis_variable = request.form['Y-axis variable']
        Color_variable = request.form['Color variable']
        Colors_vector = request.form['Colors vector']
        X_axis_variable_font_size = request.form['X-axis variable font size']
        Y_axis_variable_font_size = request.form['Y-axis variable font size']
        Legend_font_size = request.form['Legend font size']

        if len(title) == 0:
            flash('Title variable is required!please choose one!')
            return render_template('plot.html', img=url_for('static', filename='img/white.png'))
        elif len(X_axis_variable) == 0:
            flash('X_axis_variable is required!please choose one!' , category="info2")
            return render_template('plot.html', img=url_for('static', filename='img/white.png'))
        elif len(X_axis_variable_order) == 0:
            flash('X_axis_variable_order is required!please choose one!',category="info3")
            return render_template('plot.html', img=url_for('static', filename='img/white.png'))
        elif len(Y_axis_variable) == 0:
            flash('Y_axis_variable is required!please choose one!')
            return render_template('plot.html', img=url_for('static', filename='img/white.png'))
        elif len(Color_variable) == 0:
            flash('Color_variable is required!please choose one!')
            return render_template('plot.html', img=url_for('static', filename='img/white.png'))
        elif len(Colors_vector) == 0:
            flash('Colors_vector is required!please choose one!')
            return render_template('plot.html', img=url_for('static', filename='img/white.png'))
        elif content is None:
            flash('Data is required!please fill in')
            return render_template('plot.html', img=url_for('static', filename='img/white.png'))
        else:
            df = pd.read_csv(StringIO(content), sep="\t", header=0, error_bad_lines=False)
            df = pd.DataFrame(df)
            rdf = pandas2ri.py2rpy(df)
            globalenv['rdf'] = rdf
            globalenv['title'] = title
            globalenv['X_axis_variable'] = X_axis_variable
            globalenv['X_axis_variable_order'] = X_axis_variable_order
            globalenv['Y_axis_variable'] = Y_axis_variable
            globalenv['Color_variable'] = Color_variable
            globalenv['Colors_vector'] = Colors_vector
            globalenv['X_axis_variable_font_size'] = X_axis_variable_font_size
            globalenv['Y_axis_variable_font_size'] = Y_axis_variable_font_size
            globalenv['Legend_fon_size'] = Legend_font_size

            r = ro.r
            r('''
                library("magick")
                library(ggplot2)      
                library(RColorBrewer)   
                
                color1 <- brewer.pal(8, Colors_vector)
                rt = as.data.frame(rdf) 

                labels=rt[order(rt[,which(colnames(rt)==X_axis_variable_order)],decreasing =F),X_axis_variable]
                rt[,which(colnames(rt)==X_axis_variable)]=factor(rt[,which(colnames(rt)==X_axis_variable)],levels=labels)
                figure <- image_graph(width = 600, height = 400, res = 96)

                p1 = ggplot(data=rt)+geom_bar(aes(x=rt[,which(colnames(rt)==X_axis_variable)], y=rt[,which(colnames(rt)==Y_axis_variable)], fill=rt[,which(colnames(rt)==X_axis_variable_order)]), stat='identity')+
                coord_flip() + scale_fill_gradient(low=color1[1], high = color1[2])+ 
                xlab(X_axis_variable) + ylab(Y_axis_variable) + 
                theme(axis.title.x = element_text(size=as.numeric(X_axis_variable_font_size)),axis.title.y = element_text(size=as.numeric(Y_axis_variable_font_size)),axis.ticks.x = element_text(size=18),axis.ticks.y = element_text(size=18),legend.title = element_text(size = as.numeric(Legend_fon_size)),legend.text =element_text(size = 18))+
                guides(fill = guide_legend(title = X_axis_variable_order)) +
                scale_y_continuous(expand=c(0, 0)) + scale_x_discrete(expand=c(0,0)) +
                theme_bw()
                plot(p1)
                image <- image_write(figure, path = NULL, format = "png")
                ggsave( file= paste0("static/img/",title,".pdf", collapse =""), width=10,height=8)
            ''')
            figure = ro.globalenv['figure']
            image = ro.globalenv['image']
            im = Image.open(BytesIO(bytes(image)))
            f = BytesIO(bytes(image))
            data = f.getvalue()
            ims = base64.b64encode(data).decode()  # 对plot_data进行编码
            imd = "data:image/png;base64," + ims
            end_time = time.time()
            print("绘图程序执行了%f秒" % (end_time - start_time))

            return render_template('plot.html', img=imd)

    return render_template('plot.html' , img=url_for('static',filename='img/white.png'))


@app.route('/goplot', methods=('GET', 'POST'))
def goplot():
    # flash('flash test')
    if request.method == 'POST':
        """
        print(type(request.form['X-axis variable']))
        if len(request.form['X-axis variable']) ==0:
            print("test")
            flash('X-axis variable is required!please choose one!')
            print("test2")
            return render_template('plot.html', img=url_for('static', filename='img/white.png'))
            print("test3")
        else:
            print("pass")
        print(request.form['X-axis variable order'])
        """
        start_time = time.time()
        global title, content,content2, X_axis_variable, X_axis_variable_order, Y_axis_variable,sort_val, Color_variable, Colors_vector, X_axis_variable_font_size, Y_axis_variable_font_size, Legend_font_size
        title = request.form['title']
        content = request.form['content']
        X_axis_variable = request.form['X-axis variable']
        sort_val = request.form['sort.val']
        Y_axis_variable = request.form['Y-axis variable']
        Color_variable = request.form['Color variable']
        Colors_vector = request.form['Colors vector']
        X_axis_variable_font_size = request.form['X-axis variable font size']
        Y_axis_variable_font_size = request.form['Y-axis variable font size']
        Legend_font_size = request.form['Legend font size']
        print(Y_axis_variable)

        if len(title) == 0:
            flash('Title variable is required!please choose one!')
            return render_template('goplot.html', img=url_for('static', filename='img/white.png'))
        elif len(X_axis_variable) == 0:
            flash('X_axis_variable is required!please choose one!', category="info2")
            return render_template('goplot.html', img=url_for('static', filename='img/white.png'))
        elif len(sort_val) == 0:
            flash('X_axis_variable_order is required!please choose one!', category="info3")
            return render_template('goplot.html', img=url_for('static', filename='img/white.png'))
        elif len(Y_axis_variable) == 0:
            flash('Y_axis_variable is required!please choose one!')
            return render_template('goplot.html', img=url_for('static', filename='img/white.png'))
        elif len(Color_variable) == 0:
            flash('Color_variable is required!please choose one!')
            return render_template('goplot.html', img=url_for('static', filename='img/white.png'))
        elif len(Colors_vector) == 0:
            flash('Colors_vector is required!please choose one!')
            return render_template('goplot.html', img=url_for('static', filename='img/white.png'))
        elif content is None:
            flash('Data is required!please fill in')
            return render_template('goplot.html', img=url_for('static', filename='img/white.png'))
        else:
            globalenv['title'] = title
            globalenv['content'] = content
            globalenv['sort_val'] = sort_val
            globalenv['X_axis_variable'] = X_axis_variable
            globalenv['Y_axis_variable'] = Y_axis_variable
            globalenv['Color_variable'] = Color_variable
            globalenv['Colors_vector'] = Colors_vector
            globalenv['X_axis_variable_font_size'] = X_axis_variable_font_size
            globalenv['Y_axis_variable_font_size'] = Y_axis_variable_font_size
            globalenv['Legend_fon_size'] = Legend_font_size

            r = ro.r
            r('''
                        library("magick")
                        library(ggplot2)      
                        library(RColorBrewer)   
                        library(ggpubr)            
                                   
                        rt=read.table(text=content,header=T,sep="\t",check.names=F)      
                        figure <- image_graph(width = 600, height = 400, res = 96)

                        p1 = ggbarplot(rt, x="Term", y="Count", fill = "ONTOLOGY", color = "white",
                        orientation = "horiz",   #横向显示
                        palette = "aaas",    #配色方案
                        legend = "right",    #图例位置
                        sort.val = "asc",    #上升排序，区别于desc
                        sort.by.groups=TRUE)+    #按组排序
                        scale_y_continuous(expand=c(0, 0)) + scale_x_discrete(expand=c(0,0))

                        plot(p1)
                        image <- image_write(figure, path = NULL, format = "png")
                        ggsave( file= paste0("static/img/",title,".pdf", collapse =""), width=10,height=8)
                        ''')
            figure = ro.globalenv['figure']
            image = ro.globalenv['image']
            im = Image.open(BytesIO(bytes(image)))
            f = BytesIO(bytes(image))
            data = f.getvalue()
            ims = base64.b64encode(data).decode()  # 对plot_data进行编码
            imd = "data:image/png;base64," + ims
            end_time = time.time()
            print("绘图程序执行了%f秒" % (end_time - start_time))

            return render_template('goplot.html', img=imd)

    return render_template('goplot.html', img=url_for('static', filename='img/white.png'))


@app.route('/hmplot', methods=('GET', 'POST'))
def hmplot():
    # flash('flash test')
    if request.method == 'POST':
        """
        print(type(request.form['X-axis variable']))
        if len(request.form['X-axis variable']) ==0:
            print("test")
            flash('X-axis variable is required!please choose one!')
            print("test2")
            return render_template('plot.html', img=url_for('static', filename='img/white.png'))
            print("test3")
        else:
            print("pass")
        print(request.form['X-axis variable order'])
        """
        start_time = time.time()
        global title, content, type, X_axis_variable, X_axis_variable_order, Y_axis_variable, sort_val, Color_variable, Colors_vector, X_axis_variable_font_size, Y_axis_variable_font_size, Legend_font_size
        title = request.form['title']
        content = request.form['content']
        type = request.form['type']
        X_axis_variable = request.form['X-axis variable']
        sort_val = request.form['sort.val']
        Y_axis_variable = request.form['Y-axis variable']
        Color_variable = request.form['Color variable']
        Colors_vector = request.form['Colors vector']
        X_axis_variable_font_size = request.form['X-axis variable font size']
        Y_axis_variable_font_size = request.form['Y-axis variable font size']
        Legend_font_size = request.form['Legend font size']
        print(Y_axis_variable)

        if len(title) == 0:
            flash('Title variable is required!please choose one!')
            return render_template('hmplot.html', img=url_for('static', filename='img/white.png'))
        elif len(X_axis_variable) == 0:
            flash('X_axis_variable is required!please choose one!', category="info2")
            return render_template('hmplot.html', img=url_for('static', filename='img/white.png'))
        elif len(sort_val) == 0:
            flash('X_axis_variable_order is required!please choose one!', category="info3")
            return render_template('hmplot.html', img=url_for('static', filename='img/white.png'))
        elif len(Y_axis_variable) == 0:
            flash('Y_axis_variable is required!please choose one!')
            return render_template('hmplot.html', img=url_for('static', filename='img/white.png'))
        elif len(Color_variable) == 0:
            flash('Color_variable is required!please choose one!')
            return render_template('hmplot.html', img=url_for('static', filename='img/white.png'))
        elif len(Colors_vector) == 0:
            flash('Colors_vector is required!please choose one!')
            return render_template('hmplot.html', img=url_for('static', filename='img/white.png'))
        elif content is None:
            flash('Data is required!please fill in')
            return render_template('hmplot.html', img=url_for('static', filename='img/white.png'))
        else:
            globalenv['title'] = title
            globalenv['content'] = content
            globalenv['type'] = type
            globalenv['sort_val'] = sort_val
            globalenv['X_axis_variable'] = X_axis_variable
            globalenv['Y_axis_variable'] = Y_axis_variable
            globalenv['Color_variable'] = Color_variable
            globalenv['Colors_vector'] = Colors_vector
            globalenv['X_axis_variable_font_size'] = X_axis_variable_font_size
            globalenv['Y_axis_variable_font_size'] = Y_axis_variable_font_size
            globalenv['Legend_fon_size'] = Legend_font_size

            r = ro.r
            r('''
                        library("magick")
                        library(ggplot2)      
                        library(RColorBrewer)   
                        library(ggpubr)    
                        library(pheatmap)        

                        rt=read.table(text=content,header=T,sep="\t",row.names=1,check.names=F)  
                        Type=read.table(text=type, sep="\t", header=T, row.names=1, check.names=F)     
                        figure <- image_graph(width = 600, height = 400, res = 96)
                        
                        sameSample=intersect(colnames(rt),row.names(Type))
                        rt=rt[,sameSample]
                        Type=Type[sameSample,]
                        Type=Type[order(Type[,var]),]   #按临床性状排序
                        rt=rt[,row.names(Type)]

                        p1 = pheatmap(rt, annotation=Type,
                        color = colorRampPalette(c("blue", "white", "red"))(50),
                        cluster_cols =F,    #是否聚类
                        scale="row",   #基因矫正
                        show_colnames=F,
                        fontsize=10,
                        fontsize_row=9,
                        fontsize_col=5)

                        plot(p1)
                        image <- image_write(figure, path = NULL, format = "png")
                        ggsave( file= paste0("static/img/",title,".pdf", collapse =""), width=10,height=8)
                        ''')
            figure = ro.globalenv['figure']
            image = ro.globalenv['image']
            im = Image.open(BytesIO(bytes(image)))
            f = BytesIO(bytes(image))
            data = f.getvalue()
            ims = base64.b64encode(data).decode()  # 对plot_data进行编码
            imd = "data:image/png;base64," + ims
            end_time = time.time()
            print("绘图程序执行了%f秒" % (end_time - start_time))

            return render_template('hmplot.html', img=imd)

    return render_template('hmplot.html', img=url_for('static', filename='img/white.png'))

@app.route("/download")
def download_file():
    p = "static/img/" + title + ".pdf"
    return send_file(p , as_attachment=True)




"""
@app.route('/plot/barplot', methods=('POST','GET'))
def barplot():
    output = request.form.to_dict()
    #title = output["title"]
    #content = output["content"]
    title = request.form['title']
    #os.chdir("C:\\Users\\Administrator\\Desktop\\证明材料\\111bioR\\03.barplotPval")
    #content = pd.read_csv("input.txt", sep="\t", header=0, error_bad_lines=False)
    content = request.form['dataframe']
    if not title:
        flash('Title is required!')
    else:
        df = pd.DataFrame(content)
        rdf = pandas2ri.py2rpy(df)
        globalenv['rdf'] = rdf
        r = ro.r
        r('''
                library("magick")
                library(ggplot2)         
                rt = as.data.frame(rdf) 
              
                labels=rt[order(rt$FDR,decreasing =T),"Term"]
                rt$Term = factor(rt$Term,levels=labels)
                figure <- image_graph(width = 600, height = 400, res = 96)

                p1 = ggplot(data=rt)+geom_bar(aes(x=Term, y=Count, fill=FDR), stat='identity')+
                coord_flip() + scale_fill_gradient(low="red", high = "blue")+ 
                xlab("Term") + ylab("Gene count") + 
                theme(axis.text.x=element_text(color="black", size=10),axis.text.y=element_text(color="black", size=10)) + 
                scale_y_continuous(expand=c(0, 0)) + scale_x_discrete(expand=c(0,0))+
                theme_bw()
                plot(p1)
                image <- image_write(figure, path = NULL, format = "png")
        ''')
        figure = ro.globalenv['figure']
        image = ro.globalenv['image']
        im = Image.open(BytesIO(bytes(image)))
        f = BytesIO(bytes(image))
        data = f.getvalue()
        # 将matplotlib图片转换为HTML
        ims = base64.b64encode(data).decode()  # 对plot_data进行编码
        imd = "data:image/png;base64," + ims
        return render_template('plot.html', img=imd)
"""